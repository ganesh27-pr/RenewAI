from fastapi import APIRouter, HTTPException, Query, Body
from typing import List, Dict, Any

from app.models.schemas import (
    EnergyStatus,
    EnergyHistoryPoint,
    ForecastResponse,
    Recommendation,
    Alert,
    SustainabilityMetrics,
    ChatRequest,
    ChatResponse,
    ScenarioConfig,
    ScenarioInfo
)
from app.services.data_service import DataService
from app.services.optimization_service import OptimizationService
from app.services.forecasting_service import ForecastingService
from app.services.sustainability_service import SustainabilityService
from app.services.ai_service import AIService

router = APIRouter()

# Singletons for services
data_service = DataService()
optimization_service = OptimizationService()
forecasting_service = ForecastingService()
sustainability_service = SustainabilityService()
ai_service = AIService()

@router.get("/health", tags=["System"])
def get_health():
    return {
        "status": "healthy",
        "system": "RenewAI Engine",
        "version": "1.0.0-prototype"
    }

@router.get("/energy/current", response_model=EnergyStatus, tags=["Energy Data"])
def get_current_energy():
    """Returns current microgrid status including solar generation, consumption, balance, and active scenario."""
    return data_service.get_current_status()

@router.get("/energy/history", response_model=List[EnergyHistoryPoint], tags=["Energy Data"])
def get_energy_history(timeframe: str = Query("day", enum=["day", "week", "month"])):
    """Returns historical generation and consumption time series."""
    return data_service.get_history(timeframe=timeframe)

@router.get("/forecast", response_model=ForecastResponse, tags=["Forecasting"])
def get_forecast():
    """Returns 12-hour prototype forecast with upper and lower confidence bounds."""
    current_status = data_service.get_current_status()
    return forecasting_service.generate_forecast(current_status)

@router.get("/recommendations", tags=["Optimization"])
def get_recommendations():
    """Returns AI & rule-based optimization recommendations and active alerts."""
    current_status = data_service.get_current_status()
    recs, alerts = optimization_service.evaluate(current_status)
    return {
        "current_status": current_status,
        "recommendations": recs,
        "alerts": alerts
    }

@router.get("/sustainability", response_model=SustainabilityMetrics, tags=["Sustainability"])
def get_sustainability_metrics():
    """Returns estimated carbon reduction, clean energy utilization, and wastage avoided."""
    history = data_service.get_history("week")
    return sustainability_service.calculate_impact(history)

@router.post("/assistant", response_model=ChatResponse, tags=["AI Assistant"])
async def chat_with_assistant(req: ChatRequest):
    """Processes user queries about campus energy utilization, recommendations, and forecast."""
    current_status = data_service.get_current_status()
    return await ai_service.answer_query(req.message, current_status)

@router.get("/demo/scenarios", response_model=List[ScenarioInfo], tags=["Demo Mode"])
def get_demo_scenarios():
    """Returns list of 5 available demo scenarios."""
    return data_service.get_available_scenarios()

@router.post("/demo/set-scenario", response_model=ScenarioInfo, tags=["Demo Mode"])
def set_demo_scenario(config: ScenarioConfig):
    """Activates a demonstration scenario (e.g. High Solar, High Demand, Low Battery)."""
    try:
        return data_service.set_scenario(config.scenario_id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
