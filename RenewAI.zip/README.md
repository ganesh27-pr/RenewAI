# RenewAI — AI-Powered Renewable Energy Optimization System

RenewAI is a beginner-friendly AI + Sustainability prototype for a college campus. It analyses simulated renewable-energy generation and electricity consumption, estimates energy surplus/deficit, provides a simple forecast, and generates explainable energy-management recommendations.

> **Prototype note:** The included dataset is simulated. Forecasts and impact figures are demonstrations, not measured real-world results. The system is decision-support only and does not control electrical equipment.

## SDG
**Primary:** SDG 7 — Affordable and Clean Energy.

## Features
- Renewable generation vs. consumption dashboard
- Energy balance and renewable-utilization metrics
- Interactive charts
- Simple prototype forecasting
- Explainable recommendations
- Demo scenarios
- Sustainability impact estimates
- Responsible AI section
- FastAPI backend + vanilla HTML/CSS/JS frontend
- No API key required for the demo

## Project structure
```text
RenewAI/
├── backend/
│   ├── main.py
│   └── requirements.txt
├── data/
│   └── energy_data.csv
├── frontend/
│   ├── index.html
│   ├── app.js
│   └── styles.css
├── docs/
│   ├── architecture.md
│   └── responsible_ai.md
├── .gitignore
└── README.md
```

## Run locally

### 1. Backend
```bash
cd backend
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

Backend: http://127.0.0.1:8000

### 2. Frontend
From the project root, run a simple static server:

```bash
python -m http.server 5500 -d frontend
```

Open http://127.0.0.1:5500

The frontend expects the backend at `http://127.0.0.1:8000`. Change `API_BASE` in `frontend/app.js` if required.

## API
- `GET /api/health`
- `GET /api/energy/current`
- `GET /api/energy/history`
- `GET /api/forecast`
- `GET /api/recommendations`
- `GET /api/sustainability`
- `GET /api/demo/{scenario}`
- `POST /api/assistant`

## Demo scenarios
- High Solar
- High Demand
- Low Solar
- Low Battery
- Sudden Demand Increase

## Responsible AI
The project avoids personal data, labels simulated data, explains recommendation logic, and treats forecasts as uncertain decision support. See `docs/responsible_ai.md`.

## Internship alignment
The project demonstrates:
- Real-world sustainability framing
- SDG alignment
- AI/decision-support workflow
- Prototype/demo
- Responsible AI
- Expected impact
