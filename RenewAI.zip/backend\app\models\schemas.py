from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

class EnergyStatus(BaseModel):
    timestamp: str = Field(..., example="2026-09-16 14:00")
    solar_generation_kw: float = Field(..., example=62.1)
    energy_consumption_kw: float = Field(..., example=48.0)
    renewable_utilization_pct: float = Field(..., example=100.0)
    energy_balance_kw: float = Field(..., example=14.1)
    status: str = Field(..., example="Surplus")
    battery_level_percent: float = Field(..., example=95.0)
    flexible_load_kw: float = Field(..., example=18.0)
    temperature_c: float = Field(..., example=32.9)
    weather: str = Field(..., example="Sunny")
    scenario_active: Optional[str] = Field(default="Normal Operations")

class EnergyHistoryPoint(BaseModel):
    date: str
    time: str
    datetime_str: str
    solar_generation_kw: float
    energy_consumption_kw: float
    renewable_utilization_pct: float
    energy_balance_kw: float

class ForecastPoint(BaseModel):
    time_label: str
    predicted_solar_kw: float
    predicted_consumption_kw: float
    predicted_net_balance_kw: float
    status: str
    solar_upper_bound_kw: float
    solar_lower_bound_kw: float
    consumption_upper_bound_kw: float
    consumption_lower_bound_kw: float

class ForecastResponse(BaseModel):
    summary: str
    points: List[ForecastPoint]
    algorithm_explanation: str
    disclaimer: str

class Recommendation(BaseModel):
    id: str
    title: str
    description: str
    reason: str
    expected_benefit: str
    uncertainty: str
    suggested_action: str
    priority: str  # "high", "medium", "low"
    category: str  # "load_shifting", "storage", "efficiency", "alert"

class Alert(BaseModel):
    id: str
    title: str
    severity: str  # "info", "warning", "critical"
    reason: str
    suggested_action: str
    timestamp: str

class SustainabilityMetrics(BaseModel):
    total_renewable_kwh: float
    total_consumption_kwh: float
    renewable_utilization_pct: float
    estimated_co2_avoided_kg: float
    estimated_wastage_avoided_kwh: float
    trees_equivalent: int
    grid_emission_factor: str
    disclaimer: str

class ChatRequest(BaseModel):
    message: str

class ChatResponse(BaseModel):
    response: str
    referenced_metrics: Dict[str, Any]
    disclaimer: str

class ScenarioConfig(BaseModel):
    scenario_id: str = Field(..., example="high_solar")

class ScenarioInfo(BaseModel):
    id: str
    name: str
    description: str
    icon: str
