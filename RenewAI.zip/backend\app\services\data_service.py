import os
import pandas as pd
from typing import List, Dict, Any, Optional
from app.models.schemas import EnergyStatus, EnergyHistoryPoint, ScenarioInfo

class DataService:
    def __init__(self, data_path: str = None):
        if data_path is None:
            # Resolve relative to project root
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            data_path = os.path.join(base_dir, "data", "energy_data.csv")
        
        self.data_path = data_path
        self.active_scenario: str = "default"
        self.df = self._load_data()
        
        self.scenarios: Dict[str, ScenarioInfo] = {
            "default": ScenarioInfo(
                id="default",
                name="Normal Operations",
                description="Standard live campus microgrid operations with sunny peak generation.",
                icon="☀️"
            ),
            "high_solar": ScenarioInfo(
                id="high_solar",
                name="High Solar Generation",
                description="Peak midday solar irradiance producing max renewable output (75+ kW).",
                icon="☀️"
            ),
            "high_demand": ScenarioInfo(
                id="high_demand",
                name="High Campus Demand",
                description="Peak classroom & lab activity driving high demand (68 kW) causing supply deficit.",
                icon="⚡"
            ),
            "low_solar": ScenarioInfo(
                id="low_solar",
                name="Low Solar / Heavy Clouds",
                description="Heavy cloud cover dropping solar output significantly (8 kW).",
                icon="🌧️"
            ),
            "low_battery": ScenarioInfo(
                id="low_battery",
                name="Low Battery Storage",
                description="Campus battery reserves depleted down to 15% requiring conservation.",
                icon="🔋"
            ),
            "sudden_spike": ScenarioInfo(
                id="sudden_spike",
                name="Sudden Demand Spike",
                description="Unusual rapid load spike (+25 kW HVAC/Event) creating emergency deficit.",
                icon="📈"
            )
        }

    def _load_data(self) -> pd.DataFrame:
        if os.path.exists(self.data_path):
            df = pd.read_csv(self.data_path)
        else:
            # Generate fallback DataFrame if CSV file missing
            data = []
            for h in range(24):
                data.append({
                    "date": "2026-09-16",
                    "time": f"{h:02d}:00",
                    "solar_generation_kw": max(0.0, 60.0 * (1 - ((h - 13)/6)**2)) if 6 <= h <= 19 else 0.0,
                    "energy_consumption_kw": 20.0 + 30.0 * (1 - ((h - 12)/8)**2) if 7 <= h <= 21 else 18.0,
                    "temperature_c": 22.0 + 10.0 * (h / 24.0),
                    "weather": "Sunny" if 6 <= h <= 18 else "Clear",
                    "battery_level_percent": 75.0,
                    "flexible_load_kw": 15.0
                })
            df = pd.DataFrame(data)
        
        # Calculate derived columns
        df['datetime_str'] = df['date'] + ' ' + df['time']
        df['net_balance'] = df['solar_generation_kw'] - df['energy_consumption_kw']
        # Utilization %: min(100.0, (solar / consumption) * 100) if consumption > 0
        df['renewable_utilization_pct'] = df.apply(
            lambda r: round(min(100.0, (r['solar_generation_kw'] / r['energy_consumption_kw']) * 100.0), 1)
            if r['energy_consumption_kw'] > 0 else 100.0, axis=1
        )
        return df

    def get_available_scenarios(self) -> List[ScenarioInfo]:
        return list(self.scenarios.values())

    def set_scenario(self, scenario_id: str) -> ScenarioInfo:
        if scenario_id in self.scenarios:
            self.active_scenario = scenario_id
            return self.scenarios[scenario_id]
        raise ValueError(f"Unknown scenario ID: {scenario_id}")

    def get_current_status(self) -> EnergyStatus:
        latest = self.df.iloc[-1].to_dict()
        
        solar = float(latest['solar_generation_kw'])
        consumption = float(latest['energy_consumption_kw'])
        battery = float(latest['battery_level_percent'])
        flex_load = float(latest['flexible_load_kw'])
        temp = float(latest['temperature_c'])
        weather = str(latest['weather'])
        timestamp = str(latest['datetime_str'])
        scenario_name = self.scenarios[self.active_scenario].name

        # Apply Scenario Overrides for Demonstration Mode
        if self.active_scenario == "high_solar":
            solar = 78.5
            consumption = 42.0
            battery = 92.0
            flex_load = 18.0
            weather = "Sunny (High Solar Irradiance)"
        elif self.active_scenario == "high_demand":
            solar = 32.0
            consumption = 68.5
            battery = 45.0
            flex_load = 22.0
            weather = "Hot / High AC Usage"
        elif self.active_scenario == "low_solar":
            solar = 8.2
            consumption = 45.0
            battery = 35.0
            flex_load = 12.0
            weather = "Heavy Rain & Overcast"
        elif self.active_scenario == "low_battery":
            solar = 24.0
            consumption = 38.0
            battery = 14.0
            flex_load = 10.0
            weather = "Partly Cloudy"
        elif self.active_scenario == "sudden_spike":
            solar = 45.0
            consumption = 72.0
            battery = 50.0
            flex_load = 25.0
            weather = "Clear"

        balance = round(solar - consumption, 1)
        status_label = f"+{balance} kW Surplus" if balance >= 0 else f"{balance} kW Deficit"
        
        utilization = round(min(100.0, (solar / consumption) * 100.0), 1) if consumption > 0 else 100.0

        return EnergyStatus(
            timestamp=timestamp,
            solar_generation_kw=solar,
            energy_consumption_kw=consumption,
            renewable_utilization_pct=utilization,
            energy_balance_kw=balance,
            status=status_label,
            battery_level_percent=battery,
            flexible_load_kw=flex_load,
            temperature_c=temp,
            weather=weather,
            scenario_active=scenario_name
        )

    def get_history(self, timeframe: str = "day") -> List[EnergyHistoryPoint]:
        # Filter rows based on timeframe
        if timeframe == "day":
            subset = self.df.tail(24)
        elif timeframe == "week":
            subset = self.df.tail(168)
        else: # month or fallback
            subset = self.df

        result = []
        for _, row in subset.iterrows():
            solar = float(row['solar_generation_kw'])
            cons = float(row['energy_consumption_kw'])
            bal = round(solar - cons, 1)
            util = round(min(100.0, (solar / cons) * 100.0), 1) if cons > 0 else 100.0
            
            result.append(EnergyHistoryPoint(
                date=str(row['date']),
                time=str(row['time']),
                datetime_str=str(row['datetime_str']),
                solar_generation_kw=solar,
                energy_consumption_kw=cons,
                renewable_utilization_pct=util,
                energy_balance_kw=bal
            ))
        return result
