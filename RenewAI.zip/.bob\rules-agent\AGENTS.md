# AGENTS.md

This file provides guidance to agents when working with code in this repository.

## Before editing any backend file

Confirm which backend you are editing. Only `backend/main.py` runs. `backend/app/` is dead code.
Changes to `backend/app/services/*.py`, `backend/app/api/endpoints.py`, or `backend/app/models/schemas.py`
have **zero effect** on the running demo unless the router is first mounted in `main.py`.

## Frontend innerHTML safety

Every string from user input or API responses inserted via `innerHTML` must pass through `escapeHtml()`,
which is defined at the bottom of `frontend/app.js`. It is not imported — it is a global function.
Do not use `innerText` as a substitute for data that needs to be rendered as HTML structure.

## Adding a new scenario

Two places must be updated in sync — both use hyphenated IDs:
1. `backend/main.py` → add an entry to the `SCENARIOS` dict
2. `frontend/index.html` → add an `<option value="...">` to `#scenarioSelect`

Do not add it to `backend/app/services/data_service.py` unless the `app/` router has been mounted.

## Chart lifecycle — always destroy before re-render

Both `historyChart` and `forecastChart` are module-level globals in `app.js`.
Before calling `new Chart(...)`, always check and call `.destroy()` on the existing instance.
This pattern is already in `renderHistory()` and `renderForecast()` — follow it for any new chart.

## `pandas` is an unlisted dependency

`backend/app/services/data_service.py` imports `pandas` but it is not in `backend/requirements.txt`.
If you activate the `app/` module, add `pandas` to `requirements.txt` before running.

## CO₂ and utilization formulas — correct versions

When writing new sustainability calculations, use these correct formulas (not what `main.py` currently has):
- Utilization %: `min(solar, demand) / max(demand, 0.1) * 100`
- CO₂ avoided (kg): `min(solar, demand) * 0.7` (emission factor 0.7 kg/kWh, no `/1000`)
