# AGENTS.md

This file provides guidance to agents when working with code in this repository.

## Project overview
RenewAI is an AI for Sustainability internship prototype: FastAPI backend + vanilla HTML/CSS/JS frontend.
No framework build step. No test suite. No linter config files.

## Running the project

```bash
# Backend (must run from backend/ directory)
cd backend
uvicorn main:app --reload          # active backend — main.py is the entry point

# Frontend (from project root)
python -m http.server 5500 -d frontend
# Open http://127.0.0.1:5500
```

## Critical architectural fact — two backends exist, only one is active

`backend/main.py` is the **only running backend**. It is a self-contained FastAPI app.

`backend/app/` (with `api/endpoints.py`, `services/`, `models/schemas.py`) is a **second, modular implementation that is never mounted or imported** by `main.py`. Its router is not included anywhere. All logic in `app/` is dead code during the demo.

- Never edit `app/` expecting it to affect the running API.
- Never edit `main.py` expecting `app/schemas.py` types to apply — `main.py` uses plain dicts, not Pydantic models from `app/`.
- If you need to activate `app/`, add to `main.py`: `from app.api.endpoints import router; app.include_router(router, prefix="/api")`

## Scenario ID format — two incompatible sets

| Used by | Format | Values |
|---|---|---|
| `frontend/index.html` `<select>` + `main.py` `SCENARIOS` dict | **hyphen** | `high-solar`, `high-demand`, `low-solar`, `low-battery`, `demand-spike` |
| `backend/app/services/data_service.py` | **underscore** | `high_solar`, `high_demand`, `low_solar`, `low_battery`, `sudden_spike` |

The frontend and active backend use hyphens. The dead `app/` module uses underscores.

## Known bugs in `main.py` (do not introduce new code that repeats these)

1. **Utilization % wrong denominator** (`main.py:149`): divides by `max(solar, 0.1)` instead of `max(demand, 0.1)`. High Solar scenario shows ~60% when correct answer is 100%.
2. **CO₂ figure divided by 1000** (`main.py:191`): `utilized * 0.7 / 1000` — the `/1000` is erroneous, producing near-zero values (e.g. 0.022 kg instead of 21.7 kg).
3. **CORS misconfiguration** (`main.py:14–19`): `allow_origins=["*"]` combined with `allow_credentials=True` is an invalid CORS combination per spec; browsers block credentialed cross-origin requests when origin is wildcard.

## Field name mismatches between `main.py` and `app/` schemas

| Field | `main.py` response key | `app/models/schemas.py` field |
|---|---|---|
| Utilization | `renewable_utilization_percent` | `renewable_utilization_pct` |
| Chat reply | `answer` | `response` |
| Sustainability surplus | `surplus_kw` | `estimated_wastage_avoided_kwh` |

`frontend/app.js` is calibrated to `main.py`'s keys. Do not rename them in `main.py` without updating `app.js`.

## Code style conventions (from reading the files)

- **Backend**: plain Python dicts returned directly from route functions (no Pydantic models in `main.py`). Type hints used in `app/` services but absent in `main.py`.
- **Frontend**: vanilla JS, no modules, no bundler. All globals. `escapeHtml()` must be used for any user-supplied string inserted via `innerHTML`.
- **CSS**: single minified line per rule block in `styles.css`. CSS variables defined in `:root` at top.
- **No tests, no linter**: `requirements.txt` has only `fastapi`, `uvicorn[standard]`, `pydantic`. There is no pytest, no ruff, no eslint.

## `requirements.txt` is in `backend/`, not project root
Running `pip install -r requirements.txt` must be done from `backend/`.
`pandas` is imported in `app/services/data_service.py` but is **not listed** in `requirements.txt` — installing the dead `app/` module would require adding it.
