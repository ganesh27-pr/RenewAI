from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from pathlib import Path
import csv
from datetime import datetime

app = FastAPI(
    title="RenewAI API",
    description="AI-inspired renewable energy optimization prototype",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DATA_FILE = Path(__file__).resolve().parent.parent / "data" / "energy_data.csv"

SCENARIOS = {
    "high-solar": {
        "solar_generation_kw": 52.0,
        "energy_consumption_kw": 31.0,
        "temperature_c": 31.0,
        "weather": "Sunny",
        "battery_level_percent": 72,
        "flexible_load_kw": 8.0,
    },
    "high-demand": {
        "solar_generation_kw": 24.0,
        "energy_consumption_kw": 48.0,
        "temperature_c": 34.0,
        "weather": "Partly cloudy",
        "battery_level_percent": 46,
        "flexible_load_kw": 12.0,
    },
    "low-solar": {
        "solar_generation_kw": 12.0,
        "energy_consumption_kw": 33.0,
        "temperature_c": 27.0,
        "weather": "Rainy",
        "battery_level_percent": 58,
        "flexible_load_kw": 7.0,
    },
    "low-battery": {
        "solar_generation_kw": 40.0,
        "energy_consumption_kw": 29.0,
        "temperature_c": 30.0,
        "weather": "Sunny",
        "battery_level_percent": 18,
        "flexible_load_kw": 6.0,
    },
    "demand-spike": {
        "solar_generation_kw": 30.0,
        "energy_consumption_kw": 55.0,
        "temperature_c": 35.0,
        "weather": "Sunny",
        "battery_level_percent": 63,
        "flexible_load_kw": 15.0,
    },
}

class AssistantRequest(BaseModel):
    question: str
    scenario: str = "high-solar"

def load_history():
    with open(DATA_FILE, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def current_state(scenario="high-solar"):
    return SCENARIOS.get(scenario, SCENARIOS["high-solar"]).copy()

def recommendation(state):
    solar = state["solar_generation_kw"]
    demand = state["energy_consumption_kw"]
    battery = state["battery_level_percent"]
    balance = solar - demand

    if balance >= 15:
        return {
            "status": "surplus",
            "severity": "positive",
            "title": "High renewable availability",
            "message": "Renewable generation is comfortably above current demand.",
            "action": "Consider suitable flexible loads or storage during this high-generation period.",
            "reason": f"Generation exceeds consumption by {balance:.1f} kW.",
            "confidence": "Medium",
        }
    if balance > 0:
        return {
            "status": "surplus",
            "severity": "positive",
            "title": "Renewable surplus detected",
            "message": "Available renewable energy is above current campus demand.",
            "action": "Consider shifting suitable non-critical loads into this period.",
            "reason": f"Generation exceeds consumption by {balance:.1f} kW.",
            "confidence": "Medium",
        }
    if battery < 25 and solar > demand:
        return {
            "status": "storage",
            "severity": "warning",
            "title": "Low battery availability",
            "message": "A renewable surplus exists while the simulated battery level is low.",
            "action": "Consider prioritising appropriate storage charging if infrastructure permits.",
            "reason": f"Battery level is {battery:.0f}%.",
            "confidence": "Medium",
        }
    if balance < -15:
        return {
            "status": "deficit",
            "severity": "danger",
            "title": "High energy deficit",
            "message": "Demand is substantially higher than current renewable generation.",
            "action": "Review non-critical consumption and prepare for higher grid dependence.",
            "reason": f"Consumption exceeds generation by {abs(balance):.1f} kW.",
            "confidence": "Medium",
        }
    return {
        "status": "deficit",
        "severity": "warning",
        "title": "Potential renewable deficit",
        "message": "Current demand is higher than renewable generation.",
        "action": "Review flexible loads and monitor upcoming generation.",
        "reason": f"Consumption exceeds generation by {abs(balance):.1f} kW.",
        "confidence": "Medium",
    }

@app.get("/")
def root():
    return {"name": "RenewAI", "status": "running", "docs": "/docs"}

@app.get("/api/health")
def health():
    return {"status": "healthy", "service": "RenewAI API"}

@app.get("/api/energy/current")
def energy_current(scenario: str = "high-solar"):
    state = current_state(scenario)
    state["energy_balance_kw"] = round(
        state["solar_generation_kw"] - state["energy_consumption_kw"], 2
    )
    state["renewable_utilization_percent"] = round(
        min(state["solar_generation_kw"], state["energy_consumption_kw"])
        / max(state["solar_generation_kw"], 0.1) * 100, 1
    )
    state["scenario"] = scenario
    state["timestamp"] = datetime.now().isoformat(timespec="seconds")
    return state

@app.get("/api/energy/history")
def energy_history():
    return load_history()

@app.get("/api/forecast")
def forecast(scenario: str = "high-solar"):
    state = current_state(scenario)
    solar = state["solar_generation_kw"]
    demand = state["energy_consumption_kw"]
    factors = [0.88, 1.0, 1.08, 0.94, 0.82, 0.72]
    demand_factors = [0.94, 0.98, 1.03, 1.08, 1.12, 1.05]
    items = []
    for i, (sf, df) in enumerate(zip(factors, demand_factors), start=1):
        s = round(solar * sf, 1)
        d = round(demand * df, 1)
        items.append({
            "hour": f"+{i}h",
            "solar_generation_kw": s,
            "energy_consumption_kw": d,
            "balance_kw": round(s - d, 1),
            "status": "Surplus" if s >= d else "Deficit",
        })
    return {"type": "prototype_forecast", "scenario": scenario, "items": items}

@app.get("/api/recommendations")
def recommendations(scenario: str = "high-solar"):
    return recommendation(current_state(scenario))

@app.get("/api/sustainability")
def sustainability(scenario: str = "high-solar"):
    state = current_state(scenario)
    balance = state["solar_generation_kw"] - state["energy_consumption_kw"]
    utilized = min(state["solar_generation_kw"], state["energy_consumption_kw"])
    utilization = utilized / max(state["solar_generation_kw"], 0.1) * 100
    surplus_avoided = max(balance, 0)
    estimated_co2_kg = round(utilized * 0.7 / 1000, 3)
    return {
        "renewable_utilization_percent": round(utilization, 1),
        "surplus_kw": round(surplus_avoided, 1),
        "estimated_co2_avoided_kg": estimated_co2_kg,
        "note": "Prototype estimates only; not measured real-world impact.",
    }

@app.get("/api/demo/{scenario}")
def demo(scenario: str):
    if scenario not in SCENARIOS:
        raise HTTPException(status_code=404, detail="Unknown demo scenario")
    return {
        "scenario": scenario,
        "current": energy_current(scenario),
        "recommendation": recommendation(current_state(scenario)),
    }

@app.post("/api/assistant")
def assistant(payload: AssistantRequest):
    state = current_state(payload.scenario)
    rec = recommendation(state)
    q = payload.question.lower()

    if "why" in q and "surplus" in q:
        answer = rec["reason"] + " " + rec["message"]
    elif "what" in q or "recommend" in q or "should" in q:
        answer = f"{rec['title']}. {rec['action']}"
    elif "battery" in q:
        answer = f"The simulated battery level is {state['battery_level_percent']:.0f}%. " + rec["action"]
    elif "solar" in q or "generation" in q:
        answer = f"Current simulated solar generation is {state['solar_generation_kw']:.1f} kW. " + rec["message"]
    else:
        answer = f"Current balance is {state['solar_generation_kw'] - state['energy_consumption_kw']:.1f} kW. {rec['action']}"

    return {
        "answer": answer,
        "confidence": rec["confidence"],
        "disclaimer": "Prototype decision support using simulated data; verify recommendations before real-world action.",
    }
