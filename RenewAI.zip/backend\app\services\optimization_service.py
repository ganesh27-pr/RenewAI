import uuid
from typing import List
from app.models.schemas import EnergyStatus, Recommendation, Alert

class OptimizationService:
    def evaluate(self, status: EnergyStatus) -> tuple[List[Recommendation], List[Alert]]:
        recs: List[Recommendation] = []
        alerts: List[Alert] = []
        
        solar = status.solar_generation_kw
        cons = status.energy_consumption_kw
        bal = status.energy_balance_kw
        batt = status.battery_level_percent
        flex = status.flexible_load_kw

        # 1. Recommendation: Load Shifting during Surplus
        if bal > 5.0:
            recs.append(Recommendation(
                id=str(uuid.uuid4()),
                title="Shift Flexible Campus Loads to Current Window",
                description=f"Campus solar generation currently exceeds consumption by +{bal} kW. Shift non-critical loads (e.g. water pumping, thermal storage, EV charging) into this high-solar window.",
                reason="Solar generation is higher than campus electrical demand, leading to clean energy surplus.",
                expected_benefit=f"Increases renewable energy utilization by up to {round(min(25.0, bal), 1)} kWh and reduces peak grid import cost.",
                uncertainty="Low. Recommendation depends on current sunshine persistence and flexible load availability.",
                suggested_action="Schedule automated water pumps and EV charging stations immediately.",
                priority="high",
                category="load_shifting"
            ))

        # 2. Recommendation: Battery Charging during High Solar Output
        if solar > 40.0 and batt < 85.0:
            recs.append(Recommendation(
                id=str(uuid.uuid4()),
                title="Direct Excess Solar Power to Campus Battery Storage",
                description=f"Battery state of charge is at {batt}%. Direct up to {round(min(15.0, solar - cons), 1)} kW excess solar into energy storage.",
                reason="High solar irradiance presents an ideal window to buffer electrical storage for evening peak campus demand.",
                expected_benefit="Buffers campus microgrid against evening demand spikes and cloudy weather fluctuations.",
                uncertainty="Minimal. Dependent on battery charge rate limit and maximum capacity.",
                suggested_action="Enable automatic BESS (Battery Energy Storage System) charging mode.",
                priority="medium",
                category="storage"
            ))

        # 3. Recommendation: Deficit Management & Conservation
        if bal < -5.0:
            recs.append(Recommendation(
                id=str(uuid.uuid4()),
                title="Initiate Moderate Load Conservation in Academic Buildings",
                description=f"Campus consumption exceeds local renewable generation by {abs(bal)} kW. Grid power import is required.",
                reason="Solar output is insufficient to meet peak classroom and laboratory demand.",
                expected_benefit="Reduces carbon footprint from grid reliance and mitigates peak demand utility charges.",
                uncertainty="Moderate. Depends on occupant comfort tolerance and building management system response.",
                suggested_action="Adjust HVAC cooling setpoints by +1.5°C in non-essential areas and curtail idle lab equipment.",
                priority="high",
                category="efficiency"
            ))

        # 4. Recommendation: Low Battery Warning
        if batt < 25.0:
            recs.append(Recommendation(
                id=str(uuid.uuid4()),
                title="Conserve Energy Storage Reserve",
                description=f"Campus battery storage is low at {batt}%. Limit battery discharge to critical backup circuits.",
                reason="Low state of charge leaves minimal buffer for emergency load support.",
                expected_benefit="Preserves reserve capacity for emergency lighting and core server infrastructure.",
                uncertainty="Low uncertainty.",
                suggested_action="Pause non-essential battery discharge and prepare for grid standby.",
                priority="high",
                category="storage"
            ))

        # Alerts Generation Logic
        if bal < -15.0:
            alerts.append(Alert(
                id=str(uuid.uuid4()),
                title="Significant Energy Deficit Detected",
                severity="warning",
                reason=f"Campus energy demand exceeds renewable generation by {abs(bal)} kW.",
                suggested_action="Review flexible loads and consider shedding non-critical HVAC circuits.",
                timestamp=status.timestamp
            ))

        if cons > 60.0:
            alerts.append(Alert(
                id=str(uuid.uuid4()),
                title="Peak Campus Consumption Warning",
                severity="critical" if bal < 0 else "warning",
                reason=f"Campus power consumption reached peak level of {cons} kW.",
                suggested_action="Check major lab equipment and auditorium AC units for unexpected loads.",
                timestamp=status.timestamp
            ))

        if batt < 20.0:
            alerts.append(Alert(
                id=str(uuid.uuid4()),
                title="Low Battery Reserve Alert",
                severity="critical",
                reason=f"Campus energy storage is critically low ({batt}%).",
                suggested_action="Avoid unnecessary battery discharge until solar generation recovers.",
                timestamp=status.timestamp
            ))

        if bal > 10.0:
            alerts.append(Alert(
                id=str(uuid.uuid4()),
                title="High Renewable Surplus Available",
                severity="info",
                reason=f"Surplus solar power (+{bal} kW) is currently available.",
                suggested_action="Optimal time to run heavy scheduled loads or charge electric maintenance vehicles.",
                timestamp=status.timestamp
            ))

        return recs, alerts
