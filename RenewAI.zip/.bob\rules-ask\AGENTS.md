# AGENTS.md

This file provides guidance to agents when working with code in this repository.

## Where the real logic lives vs. where it appears to live

- **`backend/app/services/`** contains the sophisticated logic (multi-recommendation engine, forecast with
  confidence bounds, full sustainability metrics) — but none of it runs. The active logic is the compact
  inline functions in `backend/main.py` (`recommendation()`, `forecast()`, `sustainability()`).
- **`docs/architecture.md`** shows a mermaid diagram referencing "Optimization / Recommendation Engine" and
  "Prototype Forecast" as separate boxes — this describes the `app/` module, not what actually executes.
- **`README.md`** lists `GET /api/demo/{scenario}` — this route exists only in `main.py`, not in `app/endpoints.py`.

## Chat assistant capability

The `/api/assistant` endpoint in `main.py` is a simple keyword-match function (not the `AIService` class
in `app/services/ai_service.py`). It matches on `"why"+"surplus"`, `"what"/"recommend"/"should"`, `"battery"`,
`"solar"/"generation"`, and a catch-all. There is no AI model call. The `AIService` class (with OpenAI
fallback) is in `app/` and is dead code.

## Responsible AI claims vs. implementation

`docs/responsible_ai.md` states "Every recommendation includes a reason" — `main.py`'s `recommendation()`
does return a `reason` field, and the frontend renders it as `"Why: {rec.reason}"`. This is accurate.
The "uncertainty" field mentioned in earlier suggestions maps to `rec.confidence` in `main.py` (always `"Medium"`).

## Field names the frontend actually reads (from `app.js`)

From `/api/energy/current`: `solar_generation_kw`, `energy_consumption_kw`, `energy_balance_kw`,
`renewable_utilization_percent` (not `_pct`), `weather`.

From `/api/recommendations`: `severity`, `title`, `message`, `action`, `reason`, `confidence` — flat object, not a list.

From `/api/sustainability`: `renewable_utilization_percent`, `surplus_kw`, `estimated_co2_avoided_kg`.

From `/api/assistant` (POST): `answer`, `disclaimer` — not `response`.

From `/api/forecast`: `items` array, each with `hour`, `solar_generation_kw`, `energy_consumption_kw`.
