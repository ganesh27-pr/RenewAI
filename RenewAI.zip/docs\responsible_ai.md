# Responsible AI

## Fairness
Recommendations should be based on relevant energy data rather than assumptions about particular groups of users.

## Transparency
Every recommendation includes a reason and the dashboard distinguishes measured/simulated values from estimates and predictions.

## Privacy
The prototype does not require personal or sensitive user information.

## Human oversight
RenewAI is a decision-support system. A human energy manager should validate recommendations before taking real-world action.

## Uncertainty
Forecasts are labelled as prototype forecasts. They are not guarantees.

## Data quality
The included CSV is simulated demonstration data. Real deployment would require validated campus measurements and suitable data governance.

## Safety
The prototype does not directly control electrical equipment.
