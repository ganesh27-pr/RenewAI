# RenewAI Architecture

```mermaid
flowchart TD
    A[Simulated Energy Data] --> B[FastAPI Data Layer]
    B --> C[Energy Balance Analysis]
    B --> D[Prototype Forecast]
    C --> E[Optimization / Recommendation Engine]
    D --> E
    E --> F[RenewAI Dashboard]
    E --> G[AI Assistant]
    F --> H[Sustainability Metrics]
```

## Core flow
Data → Analysis → Forecast → Optimization → Recommendation → Human decision.

The prototype deliberately avoids automatic control of physical equipment.
