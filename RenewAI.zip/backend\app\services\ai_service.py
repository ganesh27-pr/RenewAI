import os
import httpx
from typing import Dict, Any, List
from app.models.schemas import EnergyStatus, ChatResponse

class AIService:
    def __init__(self):
        self.openai_key = os.getenv("OPENAI_API_KEY", "").strip()
        self.gemini_key = os.getenv("GEMINI_API_KEY", "").strip()

    async def answer_query(self, message: str, current_status: EnergyStatus, history_summary: str = "") -> ChatResponse:
        query_lower = message.lower()
        
        # Check if an external LLM key is configured
        if self.openai_key:
            try:
                return await self._call_openai(message, current_status)
            except Exception as e:
                # Fallback to local heuristic engine if API call fails
                pass
                
        # Smart local heuristic AI engine
        return self._generate_local_response(query_lower, message, current_status)

    def _generate_local_response(self, query_lower: str, original_query: str, status: EnergyStatus) -> ChatResponse:
        solar = status.solar_generation_kw
        cons = status.energy_consumption_kw
        bal = status.energy_balance_kw
        batt = status.battery_level_percent
        weather = status.weather
        scenario = status.scenario_active

        referenced = {
            "solar_generation_kw": solar,
            "energy_consumption_kw": cons,
            "energy_balance_kw": bal,
            "battery_level_percent": batt,
            "weather": weather,
            "scenario": scenario
        }

        # Query Intent Routing
        if any(w in query_lower for w in ["how", "renewable", "using", "usage", "current"]):
            if bal >= 0:
                resp = (
                    f"The college campus is currently operating with a **renewable energy surplus of +{bal} kW**. "
                    f"Solar generation ({solar} kW) exceeds total electricity consumption ({cons} kW). "
                    f"Our clean renewable utilization rate is **{status.renewable_utilization_pct}%**. "
                    f"Current weather is {weather} and battery storage is at {batt}% capacity."
                )
            else:
                resp = (
                    f"The campus is currently experiencing an **energy deficit of {bal} kW**. "
                    f"Campus power demand ({cons} kW) is higher than active solar output ({solar} kW). "
                    f"The remaining demand is being satisfied by battery storage ({batt}%) and grid import."
                )

        elif any(w in query_lower for w in ["should we use", "more electricity", "now", "flexible load", "schedule"]):
            if bal > 10.0:
                resp = (
                    f"**Yes! Now is an optimal time to run flexible loads.** "
                    f"Solar generation ({solar} kW) currently exceeds campus demand by **+{bal} kW**. "
                    f"We recommend activating water pumps, thermal storage, or charging electric vehicles right now "
                    f"to maximize free clean energy utilization."
                )
            elif bal > 0:
                resp = (
                    f"**Moderate power usage is fine.** Solar generation ({solar} kW) slightly exceeds campus demand by +{bal} kW. "
                    f"You can operate standard flexible loads, but monitor battery levels ({batt}%)."
                )
            else:
                resp = (
                    f"**No, energy conservation is advised right now.** "
                    f"Campus power consumption ({cons} kW) exceeds solar generation ({solar} kW) by {abs(bal)} kW. "
                    f"Running additional heavy flexible loads right now will increase carbon emissions and peak grid tariff costs."
                )

        elif any(w in query_lower for w in ["when", "peak", "highest", "expected"]):
            resp = (
                f"Based on campus microgrid solar patterns, solar generation typically reaches its **peak between 11:30 AM and 2:30 PM**, "
                f"reaching up to 65.0 kW under clear conditions ({weather}). "
                f"Currently at {status.timestamp.split()[-1] if ' ' in status.timestamp else status.timestamp}, generation is at {solar} kW."
            )

        elif any(w in query_lower for w in ["cause", "deficit", "why", "shortage", "high consumption"]):
            if bal < 0:
                resp = (
                    f"The current **{abs(bal)} kW energy deficit** is driven by high campus building consumption ({cons} kW) "
                    f"relative to current solar array output ({solar} kW). "
                    f"Contributing factors include: weather condition ({weather}) and active campus HVAC/lab baseline loads."
                )
            else:
                resp = (
                    f"There is **no energy deficit currently**. The campus is operating in surplus (+{bal} kW). "
                    f"Solar generation ({solar} kW) fully covers campus electrical load ({cons} kW)."
                )

        elif any(w in query_lower for w in ["improve", "optimize", "recommendation", "better", "save"]):
            resp = (
                f"To improve renewable energy utilization on campus, RenewAI recommends three key actions:\n"
                f"1. **Automated Load Shifting**: Program heavy loads (water pumps, EV chargers) during peak solar hours (11:00 AM - 2:00 PM).\n"
                f"2. **BESS Optimization**: Direct excess solar into battery storage when battery level is below 80% (currently {batt}%).\n"
                f"3. **HVAC Setpoint Adjustments**: Dynamically increase cooling setpoints by 1°C during power deficit windows."
            )

        else:
            resp = (
                f"RenewAI Assistant summary for campus energy status ({scenario}):\n\n"
                f"- **Solar Output**: {solar} kW\n"
                f"- **Campus Demand**: {cons} kW\n"
                f"- **Net Balance**: {status.status}\n"
                f"- **Battery Storage**: {batt}%\n"
                f"- **Weather**: {weather}\n\n"
                f"You can ask me specific questions like 'Should we use more electricity now?' or 'How is the campus using renewable energy?'"
            )

        return ChatResponse(
            response=resp,
            referenced_metrics=referenced,
            disclaimer="RenewAI Assistant operates as an advisory decision-support prototype. Recommendations should be verified by campus facilities teams."
        )

    async def _call_openai(self, message: str, current_status: EnergyStatus) -> ChatResponse:
        system_prompt = (
            "You are RenewAI Assistant, an AI advisor for a college campus energy manager. "
            "Use the provided campus microgrid data to give concise, professional, actionable advice on renewable energy optimization. "
            "Never fabricate data. If data is missing, clearly state so."
        )
        user_prompt = (
            f"Current Campus State:\n"
            f"- Solar: {current_status.solar_generation_kw} kW\n"
            f"- Consumption: {current_status.energy_consumption_kw} kW\n"
            f"- Balance: {current_status.energy_balance_kw} kW ({current_status.status})\n"
            f"- Battery: {current_status.battery_level_percent}%\n"
            f"- Weather: {current_status.weather}\n\n"
            f"User Question: {message}"
        )
        async with httpx.AsyncClient(timeout=10.0) as client:
            res = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {self.openai_key}"},
                json={
                    "model": "gpt-3.5-turbo",
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    "temperature": 0.3
                }
            )
            data = res.json()
            answer = data["choices"][0]["message"]["content"]
            return ChatResponse(
                response=answer,
                referenced_metrics=current_status.model_dump(),
                disclaimer="AI Generated Advice (OpenAI API). Advisory only."
            )
