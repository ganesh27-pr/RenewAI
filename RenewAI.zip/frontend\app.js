const API_BASE = "http://127.0.0.1:8000";
let historyChart, forecastChart;

async function api(path, options) {
  const res = await fetch(API_BASE + path, options);
  if (!res.ok) throw new Error(`API error ${res.status}`);
  return res.json();
}

function fmt(v, suffix="") {
  return `${Number(v).toFixed(1)}${suffix}`;
}

function setText(id, value) {
  document.getElementById(id).textContent = value;
}

async function loadDashboard() {
  const scenario = document.getElementById("scenarioSelect").value;
  try {
    const [current, history, forecast, rec, impact] = await Promise.all([
      api(`/api/energy/current?scenario=${scenario}`),
      api("/api/energy/history"),
      api(`/api/forecast?scenario=${scenario}`),
      api(`/api/recommendations?scenario=${scenario}`),
      api(`/api/sustainability?scenario=${scenario}`)
    ]);

    setText("solar", fmt(current.solar_generation_kw));
    setText("consumption", fmt(current.energy_consumption_kw));
    setText("balance", `${current.energy_balance_kw >= 0 ? "+" : ""}${fmt(current.energy_balance_kw)}`);
    setText("utilization", fmt(current.renewable_utilization_percent));
    setText("weather", current.weather);

    const recBox = document.getElementById("recommendation");
    recBox.className = `recommendation ${rec.severity}`;
    recBox.innerHTML = `
      <div class="rec-icon">${rec.severity === "danger" ? "⚠️" : rec.severity === "warning" ? "💡" : "🌱"}</div>
      <div>
        <h3>${rec.title}</h3>
        <p>${rec.message}</p>
        <strong>Suggested action</strong>
        <p>${rec.action}</p>
        <small>Why: ${rec.reason} · Confidence: ${rec.confidence}</small>
      </div>`;

    setText("impactUtil", `${impact.renewable_utilization_percent}%`);
    setText("impactSurplus", `${impact.surplus_kw} kW`);
    setText("impactCo2", `${impact.estimated_co2_avoided_kg} kg`);

    renderHistory(history);
    renderForecast(forecast.items);
  } catch (err) {
    document.getElementById("recommendation").innerHTML =
      `<div><h3>Backend not connected</h3><p>Start FastAPI with <code>uvicorn main:app --reload</code> in the backend folder, then refresh this page.</p></div>`;
    console.error(err);
  }
}

function renderHistory(rows) {
  const labels = rows.map(r => `${r.date.slice(5)} ${r.time.slice(0,5)}`);
  const solar = rows.map(r => Number(r.solar_generation_kw));
  const demand = rows.map(r => Number(r.energy_consumption_kw));
  if (historyChart) historyChart.destroy();
  historyChart = new Chart(document.getElementById("historyChart"), {
    type: "line",
    data: { labels, datasets: [
      { label: "Solar Generation (kW)", data: solar, borderWidth: 2, tension: .35 },
      { label: "Consumption (kW)", data: demand, borderWidth: 2, tension: .35 }
    ]},
    options: { responsive: true, maintainAspectRatio: false, interaction: { mode: "index", intersect: false },
      scales: { y: { beginAtZero: true } }, plugins: { legend: { position: "bottom" } } }
  });
}

function renderForecast(items) {
  if (forecastChart) forecastChart.destroy();
  forecastChart = new Chart(document.getElementById("forecastChart"), {
    type: "bar",
    data: { labels: items.map(x => x.hour), datasets: [
      { label: "Solar (kW)", data: items.map(x => x.solar_generation_kw) },
      { label: "Consumption (kW)", data: items.map(x => x.energy_consumption_kw) }
    ]},
    options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true } }, plugins: { legend: { position: "bottom" } } }
  });
}

document.getElementById("scenarioSelect").addEventListener("change", loadDashboard);

document.getElementById("chatForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const input = document.getElementById("question");
  const question = input.value.trim();
  if (!question) return;
  const chat = document.getElementById("chat");
  chat.insertAdjacentHTML("beforeend", `<div class="chat-bubble user">${escapeHtml(question)}</div>`);
  input.value = "";
  const scenario = document.getElementById("scenarioSelect").value;
  try {
    const result = await api("/api/assistant", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({question, scenario})
    });
    chat.insertAdjacentHTML("beforeend", `<div class="chat-bubble bot">${escapeHtml(result.answer)}<small>${escapeHtml(result.disclaimer)}</small></div>`);
  } catch {
    chat.insertAdjacentHTML("beforeend", `<div class="chat-bubble bot">I couldn't reach the backend. Please check that FastAPI is running.</div>`);
  }
  chat.scrollTop = chat.scrollHeight;
});

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;" }[c]));
}

loadDashboard();
