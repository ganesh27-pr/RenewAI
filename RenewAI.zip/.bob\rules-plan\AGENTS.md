# AGENTS.md

This file provides guidance to agents when working with code in this repository.

## Dual-backend architectural constraint

The codebase has two parallel, incompatible FastAPI implementations:
- **Active**: `backend/main.py` — monolithic, plain dicts, hyphenated scenario IDs, no Pydantic models
- **Dormant**: `backend/app/` — modular service layer, Pydantic models, underscored scenario IDs, never mounted

Any plan that involves "the recommendation engine" or "the sustainability service" must specify which
implementation it targets. Activating `app/` requires: mounting the router in `main.py`, resolving scenario
ID format differences, aligning 3 field name mismatches, and adding `pandas` to `requirements.txt`.

## Frontend has no build step — changes are immediate

There is no bundler, transpiler, or asset pipeline. Editing `frontend/app.js`, `frontend/index.html`, or
`frontend/styles.css` takes effect on the next browser refresh. No rebuild needed.

## State is scenario-driven, not time-driven

The "current" energy state is entirely determined by the selected demo scenario — it is not polled from
a live sensor or updated on a timer. `main.py`'s `SCENARIOS` dict is the sole source of truth for metric
values. The CSV (`data/energy_data.csv`) is only used by the history chart endpoint, which ignores scenario.

## History chart is scenario-blind

`GET /api/energy/history` returns all 20 CSV rows regardless of scenario. There is no mechanism to make
the history chart reflect a scenario change. Any plan to make charts "respond to scenario" must account
for this: the history endpoint would need a scenario parameter and per-row multipliers, or the chart
would need to be generated synthetically from `SCENARIOS` values.

## No persistence layer

There is no database, no session state, no file writes. Scenario selection is a query parameter on each
request — there is no server-side "active scenario" state in `main.py` (unlike `app/data_service.py`
which has `self.active_scenario`, but that service is never instantiated in the live app).

## Extension points require touching exactly two files

To add a new scenario: `SCENARIOS` dict in `main.py` + `<option>` in `index.html`.
To add a new metric card: `main.py` response dict + `index.html` HTML + `app.js` `setText()` call.
To add a new chart: `app.js` (render function + destroy guard) + `index.html` (`<canvas>` element).
No other files need changes for any of these additions.
