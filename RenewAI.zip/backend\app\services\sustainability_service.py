from typing import List
from app.models.schemas import SustainabilityMetrics, EnergyHistoryPoint

class SustainabilityService:
    def calculate_impact(self, history: List[EnergyHistoryPoint]) -> SustainabilityMetrics:
        if not history:
            return SustainabilityMetrics(
                total_renewable_kwh=0.0,
                total_consumption_kwh=0.0,
                renewable_utilization_pct=0.0,
                estimated_co2_avoided_kg=0.0,
                estimated_wastage_avoided_kwh=0.0,
                trees_equivalent=0,
                grid_emission_factor="0.85 kg CO2 / kWh (Regional Grid Baseline)",
                disclaimer="Estimated / Prototype Calculation for educational demonstration."
            )
        
        # Aggregate hourly records
        total_solar_kwh = sum(h.solar_generation_kw for h in history)
        total_cons_kwh = sum(h.energy_consumption_kw for h in history)
        
        # Clean energy actually utilized directly by campus demand or battery
        clean_energy_used = min(total_solar_kwh, total_cons_kwh)
        
        # Grid emission intensity baseline: 0.85 kg CO2 per kWh of fossil grid power
        co2_avoided_kg = clean_energy_used * 0.85
        
        # Wastage avoided by shifting loads into surplus windows (~15% of surplus)
        surplus_kwh = sum(max(0.0, h.solar_generation_kw - h.energy_consumption_kw) for h in history)
        wastage_avoided = surplus_kwh * 0.45  # 45% of surplus successfully redirected via optimization recommendations
        
        utilization_pct = round((clean_energy_used / total_solar_kwh) * 100.0, 1) if total_solar_kwh > 0 else 0.0
        trees = int(co2_avoided_kg / 20.0) # ~20 kg CO2 absorbed per tree per year
        
        return SustainabilityMetrics(
            total_renewable_kwh=round(total_solar_kwh, 1),
            total_consumption_kwh=round(total_cons_kwh, 1),
            renewable_utilization_pct=utilization_pct,
            estimated_co2_avoided_kg=round(co2_avoided_kg, 1),
            estimated_wastage_avoided_kwh=round(wastage_avoided, 1),
            trees_equivalent=trees,
            grid_emission_factor="0.85 kg CO2 / kWh (Standard Regional Grid Baseline)",
            disclaimer="Estimated / Prototype Calculation: Values are calculated based on simulated campus data and standard emission conversion factors."
        )
